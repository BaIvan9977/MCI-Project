                                                         
                                                         
                                                         
                                                        
Project management roles: 
    I have contributed around 25% of the project management work. I was responsible for writing agendas and minutes for the second, sixth, and Eleventh week.In coding aspect, I was responsible for backend programing along with Han Yan.  

Average hours spent: 
    average 23 hours was spent in the project each week. Details are displayed in the timesheets.
