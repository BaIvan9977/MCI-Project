# Individual Summary
## 1.	Project roles
As a developer, I made contributions to the front-end development.

As the secretary, I was responsible for writing agendas and minutes for the third, seventh, and Eleventh week.
## 2.	Contributions to GitHub
Yingbo Chen and I were in charge of the front-end work, most of the code was uploaded by Chen.
## 3.	Average hours invested in the project
I spent average 23 hours per week on the project. The specific activity content is in the timesheet.
