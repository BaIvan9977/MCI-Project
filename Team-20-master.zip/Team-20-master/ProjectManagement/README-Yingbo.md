# Individual Summary
## 1. Roles in the project
During this project, I worked mainly as a web front-end developer, responsible for the development and testing of web pages.

During the week I was on duty, I wrote the meeting agenda and minutes for that week as secretary.
## 2. Contributions in GitHub
As a front-end developer, I updated the front-end code (html, css and js files) in time, to share the development progress with my teammates.
## 3. Time invested
I spend an average of about 24.6 hours a week working on projects, which is roughly on par with my schedule.
