# Individual Summary

## 1.	Project management roles
During the lifecycle of the project, I played the role as the project manager, secretary, developer and tester.

•	As the project manager, I was responsible for developing the project plan, allocating tasks to team members, monitoring the progress of the project and revising the documents for project management.

•	As the secretary, I was responsible for reporting current progress and discussing problems during the client meeting and writing documents (Minutes and Agendas). 

•	As the developer, I made major (80%) contributions to the backend development and I also contributed to the frontend development (user interface design, implemented functions that communicate with the backend). 

•	As the tester, I was responsible for conducting unit testing, defect testing and integration testing.

## 2.	Contributions to GitHub
I was responsible for committing code (mainly working on the server file app.js) and documentations to GitHub. For each commit, I clearly wrote descriptions to explain what changes were made and who made contributions for that commit.

## 3.	Average hours invested in the project
I spent average 27 hours per week on the project. The activities for each week and time allocations were explained in the timesheets. 
