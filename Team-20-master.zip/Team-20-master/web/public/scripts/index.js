var app = new Vue({
    el: '#app',
    data: {
        socket: null,
        term: null,
        curr_device: null,
        devices: [
            /*{ name: 'router01', status: 'READY' },
            { name: 'router02', status: 'IN USE' },
            { name: 'router03', status: 'RESERVED' },
            { name: 'router04', status: 'READY' }*/
        ],
        scripts: [],
        executable: true,
    },
    computed: {
        cval: function () {
            
        },
        devices_open: function () {
            for(let dev of this.devices){
                if(dev.status == "OPEN"){
                    return true;
                }
            }
            return false;
        }
    },
    methods: {
        func: function (event) {
            
        },
        connect_device: function (device) {
            this.socket.emit('control',{ 'function':'connect', 'device':device });
        },
        update_browser_history: function () {
            window.history.pushState(null, this.curr_device,"?device="+this.curr_device);
        },

        openDiv1: function() {
            document.getElementById('input_control').style.display='block';
            document.getElementById('fade').style.display='block';
        },
        closeDiv1: function() {
            document.getElementById('input_control').style.display='none';
            document.getElementById('fade').style.display='none'
        },
        openDiv2: function() {
            document.getElementById('input_script').style.display='block';
            document.getElementById('fade').style.display='block';
        },
        closeDiv2: function() {
            document.getElementById('input_script').style.display='none';
            document.getElementById('fade').style.display='none'
        },
        hide: function() {
            document.getElementById('input_control').style.display='none';
            document.getElementById('input_script').style.display='none';
            document.getElementById('fade').style.display='none'

        },
        displayDropdown: function() {
            document.getElementById("myDropdown").style.display='block';
        },
        hideDropdown: function() {
            document.getElementById("myDropdown").style.display='none';
        },
        displayMyFuncsDropdown: function() {
            document.getElementById("myFuncsDropdown").style.display='block';
        },
        hideMyFuncsDropdown: function() {
            document.getElementById("myFuncsDropdown").style.display='none';
        },
        
        // Execute the selected script
        exec_script: function(name) {

            // The user can only execute the script once in every 3 seconds 
            setTimeout(()=>this.executable=true,3000);
            if(this.executable==true) {
                this.socket.emit('run_script', {filename: name });
                this.executable=false;
            }
            else{
                alert('Please retry after 3 seconds.');
            }
        },
        
        // Stop running the script at the backend
        stop_script: function(){ 
                this.socket.emit('stop_script', {stop: true});
        },
        delete_script : function(filename,index){
            var confirmed = window.confirm('Are you sure to delete "' + filename + '"?');
            if (confirmed == true)
            {
                if(filename.length>0){
                    this.socket.emit('delete_script', filename);
                    this.scripts.splice(index,1);
                }
            }           
        },
        // Allow the user to customize the blacklist
        subusrinput: function() {
            var input = document.getElementById('userinput');
            if (input.value.length > 0){
                var confirmed = window.confirm("Add your input to blocklist?");
                if (confirmed == true) {                
                    var value = input.value;
                    this.socket.emit('set_blacklist',{'keywords': value});
                    alert("'" + value + "' has been added to blacklist! ");
                    document.getElementById('userinput').value = "";
                }
            }
        },
        // Reset the block list to default
        reset_blacklist: function(){
            this.socket.emit('reset_blacklist',{sig:true});
            alert("The blocklist has been reset!");
        },
        // Filter the input in the search bar
        filterFunction: function() {
            var input, filter, a, i;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            div = document.getElementById("myDropdown");
            a = div.getElementsByTagName("a");
            for (i = 0; i < a.length; i++) {
                txtValue = a[i].textContent || a[i].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    a[i].style.display = "";
                } else {
                    a[i].style.display = "none";
                }
            }
        },
        // Function for uploading the script
        upload_script:function(){
            var filename = document.getElementById('name_input').value;
            var filecontent = document.getElementById('script_input').value;
            console.log(filename);
            console.log(filecontent);
            var confirmed = window.confirm("Are you sure to upload the customized script?");
                if (confirmed == true) {                
                    if(filename !== null && filename != '' && filecontent !== null && filecontent!='') {
                        this.socket.emit('upload_script',{name: filename, content: filecontent});
                        alert("'" + filename + "' has been uploaded!");
                        document.getElementById('name_input').value = '';
                        document.getElementById('script_input').value = '';
                    }
                    else 
                        alert("Invalid input, please enter filename and filecontent!");
                }
        },

        clearMsg: function() {
            var messages = document.getElementById('messages');
            messages.innerHTML = '';
        },

    },
    mounted() {

        this.socket = io("http://localhost:3000");

        this.socket.on('connect', function () {
            
        });

        this.socket.on('disconnect', function () {
            
        });

        // Receive the file list from the server
        this.socket.on('file_list',function(filelist){
            if(filelist !== null){
                app.scripts = filelist;
            }
        });

        // Receive the feedback from the server and display the message in a section
        this.socket.on('feedback_channel',function(msg){
            var messages = document.getElementById('messages');
            if(msg !== null){
                if(msg.message !== null){
                    console.log(msg.message);
                    var item = document.createElement('li');
                    item.textContent = msg.message;
                    messages.appendChild(item);
                    var div = document.getElementById('feedback');
                    div.scrollTo(0, div.scrollHeight);
                }
            }
        })

        // Display the data received from the server
        this.socket.on('data', function (data) {
            if(app.term !== null){
                app.term.write(data);
            }
        });

        this.socket.on('status', function (data) {
            app.devices = data;
            console.log(app.devices);
        });

        this.socket.on('control', function (data) {
            if(!('function' in data)) {
                return;
            }
            if(data.function == 'connect'){
                if('response' in data) {
                    if(data.response){

                        // Create a new terminal
                        app.term = new Terminal();

                        app.term.on('data', function (data) {
                            app.socket.emit('data', data);
                        });

                        app.term.open(document.getElementById('term'));
                        app.term.writeln('Welcome to the \x1B[1;3;31mCNA Router Lab\x1B[0m');

                    } else {
                        app.term.writeln('504 Gateway Timeout\x1B[0m');
                    }
                }
            }
        });

        // Receive and display error message
        this.socket.on('error_msg', function(msg){
            if(app.term !== null && msg !== null){
                app.term.write(msg.msg);
            }
        });

        this.curr_device = new URLSearchParams(window.location.search).get('device');
        if(this.curr_device !== null){
            this.connect_device(this.curr_device);
        }

    }
});
