#!/usr/bin/env node

var express = require('express');
var sessionstore = require('sessionstore').createSessionStore();
var session = require('express-session')({
    store: sessionstore,
    key: 'express.sid',
    secret: 'HZ5btZb5eDrP',
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: false
    }
});
var siosession = require("express-socket.io-session");
var path = require('path');
var fs = require('fs');
var net = require('net');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var request = require('request');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();
var debug = require('debug')('web:server');
var http = require('http');
var https = require('https');

var MongoClient = require('mongodb').MongoClient;

var url = "mongodb://localhost:27017/mydb";

// User name: dbuser, password: mciteam20, db name: mydb
// var url = "mongodb+srv://dbuser:mciteam20@cluster0.jybjz.mongodb.net/mydb?retryWrites=true&w=majority"

// A list that includes the device sessions
var device_sessions = {
    host01: { host: 'localhost', port: 10000, user: null, siosocks: {}, tcpsock: null },
    host02: { host: 'localhost', port: 10001, user: null, siosocks: {}, tcpsock: null },
    host03: { host: 'localhost', port: 10002, user: null, siosocks: {}, tcpsock: null },
    host04: { host: 'localhost', port: 10003, user: null, siosocks: {}, tcpsock: null },
}

app.use(session);
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({
    extended: false
}));
app.use(cookieParser());


app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

/**
 * Get port from environment and store in Express.
 */

var port = normalizePort(process.env.PORT || '3000');
app.set('port', port);

/**
 * Create HTTP server.
 */

var server = http.createServer(app);



var io = require('socket.io')(server);

// Socket.IO session
io.use(siosession(session, {
    autoSave: true
}));


/**
 * Listen on provided port, on all network interfaces.
 */

server.listen(port);
server.on('error', onError);
server.on('listening', onListening);

// Map the input with actions
var input_action_pairs = new Map();

// When a new siosock connects
io.on('connection', function (siosock) {
    
    siosock.user = siosock.handshake.session.id;
    io.sockets.sockets[siosock.id].device = null;
    io.sockets.sockets[siosock.id].user = siosock.user;

    console.log('Socket.IO connection from user '+siosock.user+'.');
  
    var tcpsock = null;
    var isRunning = false;

    // The block list
    var block_list = /(.)*/;
    
    // A filter list that is used for escaping HTTP-sepcial characters 
    var replace_list = {'<':"&lt", '>':"&gt", '&':'&amp','\"':'&quot','\'':'&apos'};

    // A set to store keywords in the block list
    var word_set = new Set();
    
    // A buffer that stores the input from the user
    var user_input = '';

    // The index of input
    var input_index = 0;

    // A set to store keywords in the check list
    var check_word_set = new Set();
    
    // Used for resolve the promise in expect
    var resolvePromise;

    // Store the latest message sent to the device
    var last_sent = '';
    var last_index = 0;


    // Send feedback to the client
    function feedback_processor(msg){
        siosock.emit('feedback_channel', {message: msg});
    }


    // Initialise the block list and the script list
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("mydb");
        var filearray = [];
        var query = {name:"blocklist"};

        // Fetch the block list from the database
        dbo.collection('block_list').find(query).toArray(function(err,result){
            if(err) throw err;
            block_list = result[0].content;

            var words_list = result[0].words;
            words_list.forEach((v)=>{word_set.add(v)});

            console.log("The current block list: " + block_list);
        });

        // Send a list to the client that contains names of scripts.
        dbo.collection('test_script').find({},{ name: 1, _id: 0 }).toArray(function(err,result){
            if(err) throw err;

            // Send the file list to the client
            siosock.emit('file_list', result);
            db.close();
        });
    });


    // Update the block list according to the user input
    siosock.on('set_blacklist',function(data){
        if(data.keywords !== null && data.keywords !== ''){
            var words = data.keywords.split("\,"); 
            // A list that stores keywords to be blocked
            var keyword_list = '';
            var word_list = [];
            var msg = '';

            for(var i=0; i<words.length;i++){
                word_set.add(words[i]);
            }

            // Construct the keyword list by appending words into the set
            word_set.forEach(v => {keyword_list += v + '|'; word_list.push(v)});
            keyword_list = keyword_list.substring(0,keyword_list.length-1);

            // Reconstruct the block list
            let s = '^((?!(' + keyword_list + ')).)*$';
            block_list = new RegExp(s,'i');

            // Update the block list in the database
            MongoClient.connect(url, function(err, db) {
                if (err) throw err;
                var dbo = db.db("mydb");

                dbo.collection("block_list").updateOne({name:"blocklist"},{$set:{name: "blocklist", content: block_list, words: word_list}},{upsert: true},
                    function(err,result){
                        if(err) throw err;
                        msg += 'Block list has been updated. Now the block list is: ' + keyword_list;
                        feedback_processor(msg);
                        console.log("blocklist updated")
                        console.log("Now the blocklist is: " + block_list);
                        db.close();
                    }
                );
            });
        }
    });


    // Reset the block list 
    siosock.on('reset_blacklist',function(data){
        if(data.sig === null){
            return;
        } 
        if(data.sig === true){
            var msg = '';
            word_set.clear();
            block_list = /(.)*/;

            // update the block list in the database
            MongoClient.connect(url, function(err, db) {
                if (err) throw err;
                var dbo = db.db("mydb");

                dbo.collection("block_list").updateOne({name:"blocklist"},{$set:{name: "blocklist", content: block_list, words:[]}},{upsert: true},
                    function(err,result){
                        if(err) throw err;
                        msg += 'Resets the block list.';
                        feedback_processor(msg);
                        db.close();
                    }
                );
            });
        }     
    });


    // Listen on the client and send any input to the terminal
    siosock.on('data', function (data) {

        if(siosock.device === null) {
            console.log("no device")
            return;
        }
        
        function block(len)
        {
               
            while(len){
                device_sessions[siosock.device].tcpsock.write('\b \b');
                len--;
            }
            
            if(!len){
               let illegal_word = '';
               
                word_set.forEach(word => 
                {
                    if(user_input.includes(word)){
                        illegal_word = word;
                        return;
                    }
                });

               check_word_set.forEach(keyword =>
               {
                    if(user_input.includes(keyword)){
                        illegal_word = keyword;
                        return;
                    }
               })

                // Send feedback to the client
                siosock.emit('error_msg', {msg:'\r\n\tIllegal input, please try again.\r\n'}); 
                let err_msg = "Illegal input detected. Your input shouldn't contain: " + illegal_word + "\n";  
                feedback_processor(err_msg);

                console.log("Input blocked, sending signal to the user..."); 
                user_input = ''; 
            }                        
        }

        var cleandata = '';
        for (var i = 0; i < data.length; i++) {
            var c = data.charAt(i);
            var cc = data.charCodeAt(i);
            var blocked = false;

            if ( cc == 0 || cc == 3 || ( cc >= 8 && cc <= 15 ) || cc == 27 || cc > 31) {

                // Sanitise special characters before sent into cleandata
                cleandata += c.replace(/[<>&\'\"]/g, w=>replace_list[w]);

                // Update the input index
                // Left arrow
                if(cc == 68 && input_index > 0){
                    input_index --;
                }
                // Right arrow
                else if(cc == 67 && input_index < user_input.length){
                    input_index ++;
                }
                // Ordinary input (characters, numbers and safe symbols)
                else if(cc != 27 && cc != 91 && cc != 127 && cc != 67 && cc != 68 && cc != 10) {
                    user_input = user_input.slice(0,input_index) + c + user_input.slice(input_index);
                    input_index++;    
                }
                // Backspace
                else if(cc == 127 && input_index > 0){
                    input_index--;
                    user_input = user_input.slice(0,input_index) + user_input.slice(input_index+1);  
                }
                
                // Sanitise the user input, then check the user input against the block list          
                if(user_input.length > 1 &&  (cc == 13 || cc == 10) ){
                    isRunning = false;
                    input_index = 0;
                    user_input = user_input.replace(/(\r\n|\n|\r)/gm, "");
                    var isValid = block_list.test(user_input);
                    var len = user_input.length;

                    // Pre-defined script: Check the user input and take actions
                    if(input_action_pairs.size > 0) {
                        for(let [keyword, statements] of input_action_pairs){
                            console.log("keyword: " + keyword + "; statements: " + statements);
                            console.log();

                            // Check if the user input includes illegal keywords defined in the script
                            if(statements.includes("block")){
                                var check_keywords = keyword.split(",");
                                for(var j = 0; j < check_keywords.length; j++){
                                    let key = check_keywords[j];
                                    if(user_input.includes(key)){

                                        for(var k=0; k < check_keywords.length; k++){
                                            check_word_set.add(check_keywords[k]);
                                        }
                                            
                                        block(len);
                                        blocked = true;
                                        break;
                                    }
                                }    
                            }

                            if(user_input.includes(keyword)){

                                // Send the message to the device
                                if(statements.includes('send')){
                                    var ind = statements.search('send') + 4;
                                    var msg = getMessage(statements.substring(ind));

                                    if(!msg.match(/\r|\n/)){
                                        msg += '\n';
                                    }
                                    
                                    device_sessions[siosock.device].tcpsock.write("\n" + msg);
                                }
                                    
                                // Provide feedback to the user
                                if(statements.includes("reply")){
                                    // console.log("in reply")
                                    var fd_idx = statements.search('reply') + 5;
                                    let rep_msg = getMessage(statements.substring(fd_idx));
                                    feedback_processor(rep_msg);
                                }
                            }
                        }
                    }

                    // If illegal input is detected, erase the input and send error message to the user 
                    if(!isValid && !blocked){
                       block(len);
                       user_input = '';
                    }
                    else{
                        console.log("Writing data {\'" + user_input + "\'} to tcpsock...");
                        user_input = '';
                    }
                    break;
                }
            }
        }

        // Establish terminal session if missing
        if(device_sessions[siosock.device].tcpsock === null){
            console.log("ready to connect")
            tcpsock = new net.Socket();
            device_sessions[siosock.device].tcpsock = tcpsock;
            
            tcpsock.rcv_msg = '';

            tcpsock.setEncoding('ascii');
            tcpsock.setKeepAlive(true);

            // Create terminal
            var params = {
                host: device_sessions[siosock.device].host,
                port: device_sessions[siosock.device].port,
                negotiationMandatory: false,
                timeout: 0,
                // removeEcho: 4
            }

            tcpsock.on('ready', function () {
                console.log("Connected to "+siosock.device+": "+device_sessions[siosock.device].host+" "+device_sessions[siosock.device].port);
            });

            tcpsock.on('timeout', function () {
                console.log('tcpsock timeout!');
                tcpsock.end();
            });

            tcpsock.on('close', function () {
                console.log('tcpsock closed');
                if (siosock.device !== null){
                    device_sessions[siosock.device].tcpsock = null;
                }
            });

            // Listen on the terminal for output and send it to the client
            tcpsock.on('data', function (data) { 

                // Keep appending data from device to the buffer
                tcpsock.rcv_msg += data;
                
                if (tcpsock.pattern != '' && tcpsock.pattern !== undefined){
                    
                    // Resolve the Promise in the current "expect" block and clear the 
                    // timer if the received message matches the expected pattern
                    if (tcpsock.rcv_msg.includes(tcpsock.pattern)){
                        tcpsock.rcv_msg = '';
                        tcpsock.pattern = '';
                        clearTimeout(tcpsock.timer);
                        resolvePromise();  
                    }   
                } 
                else {
                    tcpsock.rcv_msg = '';
                }

                // Send data to the client socket to reflect the user input on the terminal
                io.to(siosock.device).emit('data', data);
            });

            tcpsock.connect(params); 
            console.log("tcpsock created");

        }

        // Send the user input to the device
        device_sessions[siosock.device].tcpsock.write(cleandata);
    });
    

    // Insert/update the script in the database
    siosock.on('upload_script', function(file){
        MongoClient.connect(url, function(err, db) {
            if (err) throw err;
            var dbo = db.db("mydb");

            dbo.collection("test_script").updateOne({name:file.name},{$set:{name: file.name, content: file.content}},{upsert: true},
                function(err,result){
                    if(err) throw err;
                   
                    let msg = 'File: ' + file.name + ' is updated.';
                    feedback_processor(msg);
                    console.log(msg);
                    
                     // Send a list to the client that contains names of scripts.
                    dbo.collection('test_script').find({},{ name: 1, _id: 0 }).toArray(function(err,result){
                        if(err) throw err;

                        // Send the file list to the client
                        siosock.emit('file_list', result);
                        db.close();
                    });

                }
            );
        });
    });


    // Delete the script from the database
    siosock.on('delete_script',function(filename){
        if(filename.length>0){
            MongoClient.connect(url, function(err, db){
                if(err) throw err;
                var dbo = db.db("mydb");
                var query = {name: filename};

                dbo.collection("test_script").deleteOne(query, function(err,res){
                    if(err) throw err;
                    console.log(filename + " is successfully deleted.");
                    feedback_processor("File: " + filename + " is successfully deleted.")
                    db.close();
                });   
            });
        }
    });


    // Extract the file content from the database and execute the script
    siosock.on('run_script', function(sig){
        if(sig == null){
            return;
        }
        if(sig.filename !== null && tcpsock !== null){
            var lines = '';
            MongoClient.connect(url, function(err, db) {
                if (err) throw err;
                var dbo = db.db("mydb");
                var query = { name: sig.filename };

                dbo.collection("test_script").find(query).toArray(function(err, result) {
                    if (err) throw err;
                    var content = result[0].content;
                    var lines = content.split(/\r?\n/);

                    let msg = 'Start running: ' + sig.filename + '.';
                    feedback_processor(msg);

                    isRunning = true;

                    // Interpreting and running the pre-defined script
                    interpreter(lines);

                    db.close();
                });
            });                
        }
    });

    // Stop running the continuous script 
    siosock.on('stop_script', function(sig){
        if(sig === null){
            return;
        }
        if(sig.stop == true){
            input_action_pairs.clear();
            feedback_processor('Stop running the script.')
        }
    });

    // Judge if the character is digit
    function isDigit(c){
        if(c >= '0' && c <= '9'){
            return true;
        }
        return false;
    }


    // Get the message from the current line
    function getMessage(line){
        var index = 0;
        var message = '';
        var upper = line.length - 1;

        while(line[index] == ' ' && index < upper){
            index++;
        }

        if(line[index] == '\"'){
            index++;
        }

        while(index < upper && line[index] != '\"'){
            message += line[index];
            index++;
        }
       
        return message;
    }


    // Update the blocklist according to the keywords in the pre-defined script
    function update_blocklist_inscript(keywords){
        if(keywords !== '' && keywords != "reset"){
            try{
                var words = keywords.split("\,"); 
                
                // A list that stores keywords to be blocked
                var keyword_list = '';
                var word_list = [];
                var msg = '';

                for(var i=0; i<words.length;i++){
                    word_set.add(words[i]);
                }

                // Construct the keyword list by appending words into the set
                word_set.forEach(v => {keyword_list += v + '|'; word_list.push(v)});
                keyword_list = keyword_list.substring(0,keyword_list.length-1);

                // Reconstruct the block list
                let s = '^((?!(' + keyword_list + ')).)*$';
                block_list = new RegExp(s,'i');

                // update the block list in the database
                MongoClient.connect(url, function(err, db) {
                    if (err) throw err;
                    var dbo = db.db("mydb");

                    dbo.collection("block_list").updateOne({name:"blocklist"},{$set:{name: "blocklist", content: block_list, words: word_list}},{upsert: true},
                        function(err,result){
                            if(err) throw err;
                            msg += 'Block list has been updated. Now the block list is: ' + keyword_list;
                            feedback_processor(msg);
                            console.log("Blocklist updated")
                            console.log("Now the blocklist is: " + block_list);
                            db.close();
                        }
                    );
                });
            }
            catch(err){
                console.log(err);
            }
        }
        else if(keywords == "reset"){
            var msg = '';
            word_set.clear();
            block_list = /(.)*/;
            
            // Update the block list in the database
            MongoClient.connect(url, function(err, db) {
                if (err) throw err;
                var dbo = db.db("mydb");

                dbo.collection("block_list").updateOne({name:"blocklist"},{$set:{name: "blocklist", content: block_list, words:[]}},{upsert: true},
                    function(err,result){
                        if(err) throw err;
                        msg += 'Resets the block list.';
                        feedback_processor(msg);
                        db.close();
                    }
                );
            });   
        }
    }


    // Run scripts continuously until receives stop signal
    function initialise_continuous_script(lines){
        script:
        for(var i=1; i< lines.length; i++){
            var line = lines[i].trim();
            
            // neglect empty lines
            if(line.length < 4){
                if(i < lines.length - 1){
                    continue script;
                }
                else
                    break;   
            }

            if(line.includes("ifincludes")){
                var idx = line.search("ifincludes") + 10;
                var keyword = getMessage(line.substring(idx)).trim();
                console.log("keywords: " + keyword);
                let actions = '';

                // Neglect the keyword
                idx += keyword.length + 3;

                if(idx < line.length - 1){
                    let statements = line.substring(idx).trim();
                    if(statements.length >= 1){
                        // Set key-value pairs
                        input_action_pairs.set(keyword, statements);
                    }
                }
            }
        }
        
        console.log("The input action map: " );

        for(let [key,value] of input_action_pairs){
            console.log("[" + key + "," + value +"]");
        }
        
    }

    // A script interpreter that can interpret and run pre-defined scripts automatically
    async function interpreter(lines) {
        try{
            // The default timeout for running the script is 60s
            var timeout = 60000;

            // The status message
            var status_msg = '';

            // Set the timeout value
            if(lines[0].split(' ')[0] == "timeout") {

                // Run a persistent script that detects user input and take actions based on user's definitions. 
                if(lines[0].split(' ')[1] == "forever"){                    
                    initialise_continuous_script(lines);
                    return;
                }
                else{
                    timeout = 1000 * parseInt(lines[0].split(' ')[1]);
                    console.log("timeout is: " + timeout + " ms");    
                }
                
            }

            /**
             * Run a script that can send message to the device and provide arbitrary
             * (user-defined) feedback to the user based on the output 
             */
            script:
            for(var i = 0; i < lines.length; i++) {
                var line = lines[i].trim();

                if(i == lines.length - 1 ){
                    tcpsock.rcv_msg = '';
                }

                // Neglect empty lines
                if(line.length < 4) {
                    if(i < lines.length - 1){
                        continue script;
                    }
                    else
                        break;    
                }

                // Reset the block list
                if(line.replace(/(\r\n|\n|\r)/gm, "") == "reset"){
                    update_blocklist_inscript("reset");
                }

                // Add keywords to the blocklist
                else if(line.includes("setblock")){
                    let keywords = getMessage(line.substring(8))
                    update_blocklist_inscript(keywords);
                }

                // Send the message to the device
                // Syntax: send "String"
                else if(line.includes("send")) {
                    var msg = getMessage(line.substring(4));
                    last_sent = msg;
                    last_index = i + 1;
                    if(!msg.match(/\r|\n/)) {
                        msg += '\n';
                    }

                    device_sessions[siosock.device].tcpsock.write(msg);
                }

                /** 
                * Keeps reading input from device until reads the expected pattern (or timeout)
                * Syntax:
                *  expect {
                *    ("string" statement?\n)*
                *    (timeout value statement?)? 
                *  }
                */ 
                else if(line.includes("expect") ){
                    var fd_msg = '';

                    var index = 0;
                    
                    // Timeout value of the current expect block
                    var expectTimeout = timeout;
                    
                    // Whether to terminate the script immediately once timeout
                    var terminateImmediately = true;


                    // Lookup for whether the expect has an independent timeout 
                    // If so, change the timeout value of the current expect 
                    for(var a = i; a < lines.length; a++){
                        if(lines[a].length > 0){
                            if(lines[a][index].includes('}')){
                                break;
                            }

                            if(lines[a].includes("timeout")){
                                
                                // Pre-record the failure message 
                                if(lines[a].includes("reply")){
                                    let ind = lines[a].search("reply") + 5
                                    status_msg += getMessage(lines[a].substring(ind));
                                }

                                // If timeout followed by "break", break out of the expect instead of exit immediately 
                                if(lines[a].includes("break")){
                                    terminateImmediately = false;
                                }
                                let val = '';
                                let curr_index = 0;
                                let curr_line = lines[a].trim();

                                while(!isDigit(curr_line[curr_index]) && curr_index < curr_line.length - 1){
                                    curr_index++;
                                }
                                while(isDigit(curr_line[curr_index]) && curr_index < curr_line.length - 1){
                                    val += curr_line[curr_index];
                                    curr_index++;
                                }

                                // Change the timeout as specified inside the expect
                                expectTimeout = 1000 * parseInt(val);
                                console.log("Timeout in the current expect: " + expectTimeout + " ms.")
                            }
                        }
                        
                    }

                    while(line[index] != '{' && line[index] != '\"' && index < line.length - 1){
                        index++;
                    }

                    if(line[index] == '{' && i < lines.length - 1){

                        expect:
                        while(!line.includes('}') && i < lines.length - 1){
                            ++i;                            
                            line = lines[i].trim();

                            if(line[0] == '\"'){
                                index = 0;
                                tcpsock.pattern = '';
                                var statement = '';

                                if(line[index] == "\"" && index < line.length - 1){
                                    index++;

                                    // Parse and store the expected pattern
                                    while(line[index] != '\"' && index < line.length - 1){
                                        tcpsock.pattern += line[index];
                                        index++;
                                    }
                                }
                                
                                console.log("Expect pattern: " + tcpsock.pattern);
                                
                                // Judge whether to continue execution
                                var isContinue = true;

                                // Create a promise waiting for the expected pattern
                                var expectPromise = new Promise(function(resolve,reject){
                                    tcpsock.rcv_msg = '';
                                    resolvePromise = resolve;
                                    rejectPromise = reject;

                                    // Return false if not receive the expected pattern within timeout
                                    tcpsock.timer = setTimeout(function(){
                                        tcpsock.rcv_msg = '';
                                        reject()
                                    },expectTimeout);

                                })
                                .then(()=>{isContinue = true})
                                .catch(()=>{isContinue = false;});

                                let waiting = await expectPromise;

                                // Timeout without break, exit immediately
                                if(!isContinue && terminateImmediately){
                                    fd_msg = "Unable to receive the expected pattern:\" " + tcpsock.pattern + "\"."
                                    feedback_processor(fd_msg);

                                    console.log("No expected pattern returned, exit.")
                                    break script;    
                                }
                                // Timeout with break, break out of the current expect
                                else if(!isContinue && !terminateImmediately){
                                    
                                    // Send failure message to client
                                    if(status_msg != ''){
                                        feedback_processor(status_msg)    
                                    }
                                    
                                    while(!lines[i].includes('}') && i < lines.length - 1){
                                            i++;
                                    }

                                    console.log("No expected pattern returned, break out of the expect")
                                    break expect;
                                }

                                if(line[index] == '\"'){
                                    index++;
                                }
            
                                // Lookup for the following statement after receiving the expected pattern                                   
                                statements = line.substring(index);

                                // No statement, break out of the expect
                                if(statements.length < 4){
                                    while(!lines[i].includes('}') && i < lines.length - 1){
                                        i++;
                                    }
                                    break expect;
                                }
                                else{

                                    // Send the message to the device
                                    if(statements.includes('send')){
                                        var ind = statements.search('send') + 4;
                                        var msg = getMessage(statements.substring(ind));

                                        if(!msg.match(/\r|\n/)){
                                            msg += '\n';
                                        }
                                        
                                        device_sessions[siosock.device].tcpsock.write(msg);
                                    }
                                    
                                    // Provide feedback to the user
                                    if(statements.includes("reply")){
                                        var fd_idx = statements.search('reply') + 5;
                                        let rep_msg = getMessage(statements.substring(fd_idx));
                                        feedback_processor(rep_msg);
                                    }

                                    // Break out of the current expect
                                    if(statements.includes("break")){
                                        while(!lines[i].includes('}') && i < lines.length - 1){
                                                i++;
                                        }
                                        console.log("break out of the expect")
                                        break expect;
                                    }

                                    // "stop" that appears in the statement indicates failed execution
                                    else if(statements.includes("stop")){
                                        feedback_processor('Failed to execute the script.');
                                        break script;
                                    } 
                                }                                   
                            }
                        }
                    }
                }

                // Provide feedback to the client
                else if(line.includes("reply")){
                    let fd_idx = line.search("reply") + 5;
                    let rep_msg = getMessage(line.substring(fd_idx));
                    feedback_processor(rep_msg);
                }

                // Exiting from the script if the current line contains "stop"
                else if(line.includes("stop")) {
                    console.log("Stop the running process")
                    
                    break script;
                }
            }

            feedback_processor("Finished.\n");
            console.log("Finished.\n")
        }

        // Report the syntax error
        catch(err){
            console.log("Please check the syntax of the script file. The error message: ");
            console.log(JSON.stringify(err));

            feedback_processor("Please check the syntax of the script file. The error message: ");
            feedback_processor(JSON.stringify(err));
        }   
    }


    // Handle control data
    siosock.on('control', function (data) {

        if(!('function' in data)) {
            return;
        }

        // Trying to connect
        if(data.function == 'connect'){

            // Device specified
            if('device' in data) {

                console.log('User '+siosock.user+' requesting device '+data.device);

                // Check if this siosock is already connected to another device
                if (siosock.device !== null && siosock.device !== data.device) {
                    delete device_sessions[siosock.device].siosocks[siosock.id];
                    if(Object.keys(device_sessions[siosock.device].siosocks).length <= 0){
                        device_sessions[siosock.device].user = null;
                        if(device_sessions[siosock.device].tcpsock !== null){
                            device_sessions[siosock.device].tcpsock.destroy();
                        }
                        device_sessions[siosock.device].tcpsock = null;
                    }
                    siosock.device = null;
                    console.log('    Session already connected to '+siosock.device+'. Cleared.');
                }
                
                siosock.device = data.device;

                if (siosock.device in device_sessions && device_sessions[siosock.device].user === null) {
                    device_sessions[siosock.device].user = siosock.user;
                } else if (!(siosock.device in device_sessions) || device_sessions[siosock.device].user != siosock.user) {
                    siosock.emit('control',{ 'function':'connect', 'response':false });
                    siosock.device = null;
                    console.log('    Device '+siosock.device+' rejected. Disconnected.');
                    return;
                }

                device_sessions[siosock.device].siosocks[siosock.id] = 1;
                siosock.join(siosock.device);

                console.log('    Device '+siosock.device+' granted.');
                siosock.emit('control',{ 'function':'connect', 'response':true });
            } else {
                console.log('Missing paramters');
                siosock.emit('control',{ 'function':'connect', 'response':false });
            }

            sendStatus();

        } else if(data.function == 'disconnect'){
            
            console.log('User '+siosock.user+' disconnect '+siosock.device);

            if (siosock.device !== null) {
                delete device_sessions[siosock.device].siosocks[siosock.id];
                siosock.leave(siosock.device);
                if(Object.keys(device_sessions[siosock.device].siosocks).length <= 0){
                    device_sessions[siosock.device].user = null;
                    if(device_sessions[siosock.device].tcpsock !== null){
                        device_sessions[siosock.device].tcpsock.destroy();
                    }
                    device_sessions[siosock.device].tcpsock = null;
                }
                siosock.device = null;
                siosock.emit('control',{ 'function':'disconnect', 'response':true });
            } else {
                siosock.emit('control',{ 'function':'disconnect', 'response':false });
            }

            sendStatus();
            
        }
    });

    // When siosock disconnects, destroy the terminal
    siosock.on("disconnect", function () {
        console.log(siosock.device);
        if (siosock.device !== null) {
            delete device_sessions[siosock.device].siosocks[siosock.id];
            if(Object.keys(device_sessions[siosock.device].siosocks).length <= 0){
                device_sessions[siosock.device].user = null;
                if(device_sessions[siosock.device].tcpsock !== null){
                    device_sessions[siosock.device].tcpsock.destroy();
                }
                device_sessions[siosock.device].tcpsock = null;
            }
            siosock.device = null;
        }
        console.log('User '+siosock.user+' disconnected.');
        sendStatus();
    });

    sendStatus();
    
});


/**
 * Normalize a port into a number, string, or false.
 */

function normalizePort(val) {
    var port = parseInt(val, 10);

    if (isNaN(port)) {
        // named pipe
        return val;
    }

    if (port >= 0) {
        // port number
        return port;
    }

    return false;
}

/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
    if (error.syscall !== 'listen') {
        throw error;
    }

    var bind = typeof port === 'string' ?
        'Pipe ' + port :
        'Port ' + port;

    // handle specific listen errors with friendly messages
    switch (error.code) {
        case 'EACCES':
            console.error(bind + ' requires elevated privileges');
            process.exit(1);
            break;
        case 'EADDRINUSE':
            console.error(bind + ' is already in use');
            process.exit(1);
            break;
        default:
            throw error;
    }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening() {
    var addr = server.address();
    var bind = typeof addr === 'string' ?
        'pipe ' + addr :
        'port ' + addr.port;
    debug('Listening on ' + bind);
}


function sendStatus() {

    Object.keys(io.sockets.sockets).forEach((socketId) => {
        const siosock = io.sockets.sockets[socketId];
        var status = [];
        Object.keys(device_sessions).forEach(function (item) {
            var s1 = { name: item, status: 'UNAVAILABLE' };
            if(device_sessions[item].user === null){
                s1.status = 'READY';
            } else if(device_sessions[item].user === siosock.user){
                s1.status = 'OPEN';
            } else {
                s1.status = 'IN USE';
            }
            status.push(s1);
        });
        io.to(socketId).emit('status',status);
    });

    console.log("Sent status update");

}

















































